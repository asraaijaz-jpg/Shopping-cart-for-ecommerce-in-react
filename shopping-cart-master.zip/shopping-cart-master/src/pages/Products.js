import React from "react";
import { Container, Header } from "semantic-ui-react";

function Products() {
  return (
    <div>
      <Header as="h2">Products</Header>
    </div>
  );
}

export default Products;
