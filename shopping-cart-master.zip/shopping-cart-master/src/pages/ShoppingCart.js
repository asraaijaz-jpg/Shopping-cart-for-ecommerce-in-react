import React from "react";
import { Container, Header } from "semantic-ui-react";

function ShoppingCart() {
  return (
    <Container>
      <Header as="h2">Shopping Cart</Header>
      {/* Show products from Shopping Cart context */}
    </Container>
  );
}

export default ShoppingCart;
